//
//  ResultView.swift
//  GradeCalculator
//
//  Created by Anthony Oshima on 11/12/24.
//
import SwiftUI

struct ResultView: View {
    let totalStudents: Double
    let aStudents: Double
    let bStudents: Double
    let cStudents: Double
    let dStudents: Double
    let fStudents: Double

    var aPercentage: Double { (aStudents / totalStudents) * 100 }
    var bPercentage: Double { (bStudents / totalStudents) * 100 }
    var cPercentage: Double { (cStudents / totalStudents) * 100 }
    var dPercentage: Double { (dStudents / totalStudents) * 100 }
    var fPercentage: Double { (fStudents / totalStudents) * 100 }

    var body: some View {
        VStack {
            Text("Grade Distribution")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding()

            HStack(alignment: .bottom, spacing: 20) {
                GradeBarView(grade: "A", percentage: aPercentage, color: .green)
                GradeBarView(grade: "B", percentage: bPercentage, color: .blue)
                GradeBarView(grade: "C", percentage: cPercentage, color: .yellow)
                GradeBarView(grade: "D", percentage: dPercentage, color: .orange)
                GradeBarView(grade: "F", percentage: fPercentage, color: .red)
            }
            .padding(.horizontal)
            .frame(maxHeight: 300)

            Spacer()
            
            VStack(alignment: .leading) {
                Text("A: \(aPercentage, specifier: "%.1f")%")
                    .font(.title2)
                    .fontWeight(.bold)
                Text("B: \(bPercentage, specifier: "%.1f")%")
                    .font(.title2)
                    .fontWeight(.bold)
                Text("C: \(cPercentage, specifier: "%.1f")%")
                    .font(.title2)
                    .fontWeight(.bold)
                Text("D: \(dPercentage, specifier: "%.1f")%")
                    .font(.title2)
                    .fontWeight(.bold)
                Text("F: \(fPercentage, specifier: "%.1f")%")
                    .font(.title2)
                    .fontWeight(.bold)
            }
            .padding(100)
        }
        .navigationTitle("Results")
    }
}

struct GradeBarView: View {
    let grade: String
    let percentage: Double
    let color: Color

    var body: some View {
        VStack {
            Text("\(percentage, specifier: "%.1f")%")
                .font(.subheadline)
                .fontWeight(.bold)
                .foregroundColor(.black)
            Rectangle()
                .fill(color)
                .frame(width: 30, height: CGFloat(percentage) * 3) 
            Text(grade)
                .font(.title)
                .fontWeight(.bold)
                .foregroundColor(.black)
        }
    }
}

struct ResultView_Previews: PreviewProvider {
    static var previews: some View {
        ResultView(
            totalStudents: 50,
            aStudents: 20,
            bStudents: 15,
            cStudents: 10,
            dStudents: 3,
            fStudents: 2
        )
    }
}
