//
//  Toast.swift
//  GradeCalculator
//
//  Created by Anthony Oshima on 11/12/24.
//
import SwiftUI

enum ToastStyle {
    case info, success, error
}

struct Toast: Equatable {
    var message: String
    var style: ToastStyle
    var width: CGFloat
    var duration: TimeInterval
}

