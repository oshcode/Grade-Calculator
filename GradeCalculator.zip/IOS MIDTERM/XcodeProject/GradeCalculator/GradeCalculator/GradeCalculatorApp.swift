//
//  GradeCalculatorApp.swift
//  GradeCalculator
//
//  Created by Anthony Oshima on 11/12/24.
//

import SwiftUI

@main
struct GradeCalculatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
