//
//  GradeData.swift
//  GradeCalculator
//
//  Created by Anthony Oshima on 11/12/24.
//
