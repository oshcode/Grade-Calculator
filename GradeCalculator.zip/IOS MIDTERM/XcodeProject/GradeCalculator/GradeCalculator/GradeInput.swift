//
//  GradeInput.swift
//  GradeCalculator
//
//  Created by Anthony Oshima on 11/12/24.
//
import SwiftUI

struct GradeInputView: View {
    @State private var totalStudentsText = ""
    @State private var aStudentsText = ""
    @State private var bStudentsText = ""
    @State private var cStudentsText = ""
    @State private var dStudentsText = ""
    @State private var fStudentsText = ""
    
    @State private var showToast = false

    func convertToDouble(_ text: String) -> Double {
        return Double(text) ?? 0.0
    }

    func calculatePercentages() -> String {
        let totalStudents = convertToDouble(totalStudentsText)
        guard totalStudents > 0 else { return "Invalid total students value" }
        
        let aPercent = (convertToDouble(aStudentsText) / totalStudents) * 100
        let bPercent = (convertToDouble(bStudentsText) / totalStudents) * 100
        let cPercent = (convertToDouble(cStudentsText) / totalStudents) * 100
        let dPercent = (convertToDouble(dStudentsText) / totalStudents) * 100
        let fPercent = (convertToDouble(fStudentsText) / totalStudents) * 100
        
        return String(format: "A: %.2f%%\nB: %.2f%%\nC: %.2f%%\nD: %.2f%%\nF: %.2f%%", aPercent, bPercent, cPercent, dPercent, fPercent)
    }

    var body: some View {
        NavigationView {
            ZStack {
                VStack(spacing: 20) {
                    TextField("Total No. of Students", text: $totalStudentsText)
                        .keyboardType(.numberPad)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(8)

                    TextField("A Students", text: $aStudentsText)
                        .keyboardType(.numberPad)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(8)
                    
                    TextField("B Students", text: $bStudentsText)
                        .keyboardType(.numberPad)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(8)
                    
                    TextField("C Students", text: $cStudentsText)
                        .keyboardType(.numberPad)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(8)
                    
                    TextField("D Students", text: $dStudentsText)
                        .keyboardType(.numberPad)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(8)
                    
                    TextField("F Students", text: $fStudentsText)
                        .keyboardType(.numberPad)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(8)

                    // Compute button
                    NavigationLink(
                        destination: ResultView(
                            totalStudents: convertToDouble(totalStudentsText),
                            aStudents: convertToDouble(aStudentsText),
                            bStudents: convertToDouble(bStudentsText),
                            cStudents: convertToDouble(cStudentsText),
                            dStudents: convertToDouble(dStudentsText),
                            fStudents: convertToDouble(fStudentsText)
                        ),
                        label: {
                            Text("Bar Graph")
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(8)
                        })
                        .padding()
                        .buttonStyle(PlainButtonStyle())
                    Spacer()
                    
                    Button(action: {
                        withAnimation {
                            showToast = true
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            withAnimation {
                                showToast = false
                            }
                        }
                    }) {
                        Text("Results")
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.green)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                }
                .padding()
                .navigationTitle("Grade Calculator")
                
                // Toast view
                if showToast {
                    VStack {
                        Text(calculatePercentages())
                            .padding()
                            .background(Color.black.opacity(0.8))
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                    .transition(.opacity)
                    .zIndex(1)
                    .padding(.top, 100)
                }
            }
        }
    }
}

struct GradeInputView_Previews: PreviewProvider {
    static var previews: some View {
        GradeInputView()
    }
}
